class Entidad():
    def __init__(self, nombre, nit, categoria, serviciosOfrecidos, direccion):
        self.__nombre = nombre
        self.__nit = nit
        self.__categoria = categoria
        self.__serviciosOfrecidos = serviciosOfrecidos
        self.__direccion = direccion
        
        
    def getNombre(self):
        return self.nombre
    def setNombre(self,nombre):
        self.__nombre = nombre
        
    def getNit(self):
        return self.nit
    def setNit(self,nit):
        self.__nit = nit
        
    def getCategoria(self):
        return self.categoria
    def setCategoria(self,categoria):
        self.__categoria = categoria 
        
    def getServiciosOfrecidos(self):
        return self.__serviciosOfrecidos
    def setServiciosOfrecidos(self,serviciosOfrecidos):
        self.__serviciosOfrecidos = serviciosOfrecidos
        
    def getDireccion(self):
        return self.direccion
    def setDireccion(self,direccion):
        self.__direccion = direccion
        
    def registrarEntidad(self):
        print("Sobre la IPS/EPS: ",'☲'*40)
        self.nombre = input("Ingrese el nombre de la IPS/EPS: ")
        self.nit = input("Ingrese el NIT de la IPS/EPS: ")
        while self.categoria != "I" or self.categoria != "II" or self.categoria != "III" or self.categoria != "IV" or self.categoria != "V":
            self.categoria = input("Ingrese la categoría de la IPS/EPS (I, II, III, IV, V): ")
            match self.categoria:
                case "I":
                    print("\nDe acuerdo a la categoría ingresada los servicios que va a ofrecer son:\n1. Consulta médica general\n2. Atención preventiva\n3. Atención de enfermedades comunes\n4. Tratamientos ambulatorios\n5. Servicios de salud materno-infantil")
                case "II":
                    print("\nDe acuerdo a la categoría ingresada los servicios que va a ofrecer son:\n1. Consulta médica general\n2. Consulta especializada\n3. Diagnóstico básico\n4. Tratamiento ambulatorios y hospitalización breve\n5. Servicios de urgencias\n5. Rehabilitación básica\n6.Atención en salud mental")
                case "III":
                    print("\nDe acuerdo a la categoría ingresada los servicios ofrecidos es:\n1. Consulta médica general\n2. Consulta especializada\n3. Diagnostico avanzado\n4. Urgencias \n5. Tratamientos básicos\n6. Cirugía general\n7. Hospitalización\n8. Atención preventiva")
                case "IV":
                    print("\nDe acuerdo a la categoría ingresada los servicios ofrecidos es:\n1. Consulta médica general\n2.Consulta especializada\n3. Diagnostico avanzado\n4. Tratamientos especializados\n6. Cirugía Especializada\n7. Unidades de cuidados intensivos (UCI)\n8. Rehabilitación avanzada")
                case "V":
                    print("\nDe acuerdo a la categoría ingresada los servicios ofrecidos es:\n1.Consulta médica general\n2.Consulta altamente especializada\n4. Diagnóstico de alta tecnología\n5. Urgencias críticas\n6. Tratamientos avanzados\n7. Tratamientos avanzados\n8. Cirugía de alta complejidad\n9. Investigación clínica\n10.Unidades de cuidados intensivos (UCI)")
        self.direccion = input("Ingrese la dirección de la IPS/EPS: ")
        nuevaEntidad = Entidad(self.nombre, self.nit, self.categoria, self.serviciosOfrecidos, self.direccion)
        self.añadirEntidad(nuevaEntidad)

    def añadirEntidad(self, nuevaEntidad):
        pass